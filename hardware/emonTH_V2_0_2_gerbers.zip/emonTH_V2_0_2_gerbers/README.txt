# emonTx TH V2.0.2 - Sep 2016

- PCB to be 1.6mm thickness
- Solder Resist: Blue
- Finish: HASL

* No silkscreen should overlap pads
* Check Welsh Daragon logo on the rear is re-produced OK :-)

glyn.hudson@openenergymonitor.org
Tel: +441248672607
Mob: +447769871550